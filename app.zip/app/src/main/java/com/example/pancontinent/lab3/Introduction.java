package com.example.pancontinent.lab3;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class Introduction extends AppCompatActivity {

    private String[] shoppinginf = {"一键下单","分享商品","不感兴趣","查看更多商品促销信息"};
    private String[] Items = {"Enchated Forest","Arla Milk","Devondale Milk",
            "Kindle Oasis","waitrose 早餐麦片","Mcvitie's 饼干",
            "Ferrero Rocher","Maltesers","Lindt","Borggreve"};
    private String[] Price = {"￥5.00","￥59.00","￥79.00","￥2399.00","￥179.00","￥14.90","￥132.59",
                                "￥141.43","￥139.43","￥28.90"};
    private String[] ItemsInf = {"作者 Johanna","产地 德国","产地 澳大利亚","版本 8GB","重量 2Kg",
                                    "产地 英国","重量 300g","重量 118g","重量 249g","重量 240g"};
    private int [] Pictures = {R.drawable.enchatedforest,R.drawable.arla,R.drawable.devondale,
                                R.drawable.kindle,R.drawable.waitrose,R.drawable.mcvitie,
                                R.drawable.ferrero,R.drawable.maltesers,R.drawable.lindt,
                                R.drawable.borggreve};
    private int flag = 0;//用于判断星星
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_introduction);
        //获取从MainActivity中传输过来的数据
        Intent intent = getIntent();
        final int CurrentPosition = intent.getIntExtra("Position",1);

        //设计购物车界面
        //最下面的信息
        ListView Inf_list = (ListView)findViewById(R.id.ShoppingInformation);
        ArrayAdapter<String> adapter1 = new ArrayAdapter<>(
                Introduction.this,android.R.layout.simple_list_item_1,shoppinginf);
        Inf_list.setAdapter(adapter1);
        //上面的界面
            //商品图片
        ImageView Picture = (ImageView)findViewById(R.id.foodpicture);
        Picture.setImageResource(Pictures[CurrentPosition]);

            //星星图标及监听
        final ImageView myStar = (ImageView)findViewById(R.id.star);
        myStar.setImageResource(R.mipmap.empty_star);
        myStar.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                if (flag==0){
                    myStar.setImageResource(R.drawable.empty_star);
                    flag=1;
                }
                else if(flag==1){
                    myStar.setImageResource(R.drawable.full_star);
                    flag=0;
                }
            }
        });
            //产品的名字
        TextView itemName = (TextView)findViewById(R.id.ItemName);
        itemName.setText(Items[CurrentPosition]);
            //返回键
        ImageView Back = (ImageView)findViewById(R.id.back);
        Back.setImageResource(R.drawable.back);
        Back.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        //中间的界面
        TextView ItemsPrice = (TextView)findViewById(R.id.price);
        TextView ItemsInformation = (TextView)findViewById(R.id.weight);
        ItemsPrice.setText(Price[CurrentPosition]);
        ItemsInformation.setText(ItemsInf[CurrentPosition]);
            //购物车按钮，按一下则添加到购物车
        ImageView AddItems = (ImageView)findViewById(R.id.logo);
        AddItems.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Toast.makeText(Introduction.this,"商品已加到购物车",Toast.LENGTH_SHORT).show();
                Intent intent2 = new Intent();
                intent2.putExtra("data_return",CurrentPosition);
                setResult(RESULT_OK,intent2);//返回产品号信息,RESULT_OK用来和返回键区分
            }
        });
    }
}
