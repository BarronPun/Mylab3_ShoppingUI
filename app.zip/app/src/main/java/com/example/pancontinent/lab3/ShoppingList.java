package com.example.pancontinent.lab3;

/**
 * Created by Pancontinent on 2017/10/21.
 */

public class ShoppingList {
    private String logo;
    private String name;
    private int ID;

    public ShoppingList(String logo, String name, int ID){
        this.logo = logo;
        this.name = name;
        this.ID = ID;
    }

    public String getLogo(){
       return logo;
    }

    public String getName(){
        return name;
    }

    public int getID(){ return ID; };
}
