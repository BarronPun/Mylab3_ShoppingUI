package com.example.pancontinent.lab3;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.animation.OvershootInterpolator;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import jp.wasabeef.recyclerview.adapters.AlphaInAnimationAdapter;
import jp.wasabeef.recyclerview.adapters.ScaleInAnimationAdapter;
import jp.wasabeef.recyclerview.adapters.SlideInRightAnimationAdapter;
import jp.wasabeef.recyclerview.animators.FlipInLeftYAnimator;
import jp.wasabeef.recyclerview.animators.LandingAnimator;
import jp.wasabeef.recyclerview.animators.OvershootInLeftAnimator;
import jp.wasabeef.recyclerview.animators.ScaleInTopAnimator;
import jp.wasabeef.recyclerview.animators.SlideInDownAnimator;

public class MainActivity extends AppCompatActivity {
    private List<ShoppingList> myshoppinglist = new ArrayList<>();
    private List<ShoppingList> myshoppingcar = new ArrayList<>();
    private int flag=0;
    private int Number=10;//要添加到购物车的产品的产品号
    private String[] Index = {"1","2","3","4","5","6","7","8","9","10"};
    private ListAdapter adapter2;
    private ShoppingAdapter adapter;
    private FloatingActionButton fab;
    private RecyclerView recyclerView;
    private ListView listView;
    //获得要添加到购物车的产品号

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fab = (FloatingActionButton)findViewById(R.id.fab);
        recyclerView = (RecyclerView)findViewById(R.id.recycler_view);
        listView = (ListView)findViewById(R.id.list_view);
        listView.setVisibility(View.GONE);//初始化，让listView不可见
        //recyclerView.setVisibility(View.INVISIBLE);
        //设置商品列表并且对商品列表中的每一项进行监听(长按和短按)
        initShoppingList();//初始化商品的数据

        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        adapter = new ShoppingAdapter(myshoppinglist);
        //recyclerView.setAdapter(adapter);
        //AlphaInAnimationAdapter alphaAdapter = new AlphaInAnimationAdapter(adapter);
        //alphaAdapter.setDuration(1000);
        //alphaAdapter.setInterpolator(new OvershootInterpolator());
        //recyclerView.setAdapter(alphaAdapter);

        ScaleInAnimationAdapter animationAdapter = new ScaleInAnimationAdapter(adapter);
        animationAdapter.setDuration(2000);
        recyclerView.setAdapter(animationAdapter);
        recyclerView.setItemAnimator(new ScaleInTopAnimator());

            //监听部分
        adapter.setOnItemClickListener(new ShoppingAdapter.OnItemClickListener(){
            @Override
            public void onItemClick(View view, int position) {
                int index = myshoppinglist.get(position).getID();
                Intent intent = new Intent(MainActivity.this,Introduction.class);
                //下面发送当前的位置给商品详情界面
                intent.putExtra("Position",index);
                startActivityForResult(intent,2);
               // Toast.makeText(MainActivity.this,"DEBUG",Toast.LENGTH_SHORT).show();
            }
        });
        adapter.setOnLongItemClickListener(new ShoppingAdapter.OnLongItemClickListener() {
            @Override
            public void onLongItemClick(View view, int position) {
                Toast.makeText(MainActivity.this,"移除第"+Index[position]+"个商品",Toast.LENGTH_SHORT).show();
                myshoppinglist.remove(position);
                adapter.notifyDataSetChanged();
            }
        });

        //设置购物车的界面并且进行监听
        initShoppingCar();
        adapter2 = new ListAdapter(MainActivity.this,
                R.layout.shoppinglist,myshoppingcar);
        adapter2.notifyDataSetChanged();
        listView.setAdapter(adapter2);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                int Index = myshoppingcar.get(position).getID();//获得当前产品ID
                if (Index!=10) {    //判断标题，标题不用监听，OR will collapse, cautious!
                    Intent intent = new Intent(MainActivity.this,Introduction.class);
                    intent.putExtra("Position",Index);
                    startActivityForResult(intent,2);
                }
            }
        });
        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener(){
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                final int temp = position;
                if (temp>0){    //开头项不能删除
                    AlertDialog.Builder dialog = new AlertDialog.Builder(MainActivity.this);
                    dialog.setTitle("移除商品");
                    dialog.setMessage("从购物车移除 "+myshoppinglist.get(myshoppingcar.get(position).getID()).getName()+"?");
                    dialog.setNegativeButton("取消",new DialogInterface.OnClickListener(){
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                        }
                    });
                    dialog.setPositiveButton("确定",new DialogInterface.OnClickListener(){
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            myshoppingcar.remove(temp);
                            adapter2.notifyDataSetChanged();
                        }
                    });
                    dialog.show();
                }
                return true;
            }
        });
        //设置悬浮按钮并且进行监听
        fab.setImageResource(R.drawable.shopping);
        flag=0;
        fab.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                if (flag==0){        //切换到购物车界面
                    fab.setImageResource(R.drawable.mainpage);
                    listView.setVisibility(View.VISIBLE);//显示ListView
                    recyclerView.setVisibility(View.GONE);//不显示RecyclerView
                    flag=1;
                }
                else if(flag==1){        //切换到商品界面
                    fab.setImageResource(R.drawable.shopping);
                    listView.setVisibility(View.GONE);//不显示ListView
                    recyclerView.setVisibility(View.VISIBLE);//显示RecycleView
                    flag=0;
                }
            }
        });

    }
    //重载函数，根据返回的Number的值，然后将第Number+1个商品添加到购物车并且刷新，商品从第1个开始计数
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode){
            case 2:
                if (resultCode == RESULT_OK){
                    Number = data.getIntExtra("data_return",2);
                    addToShoppingCar(Number);
                    adapter2.notifyDataSetChanged();
                }
                break;
            default:
        }
    }

    private void initShoppingList(){

            ShoppingList item1 = new ShoppingList("E","Enchated Forest",0);
            myshoppinglist.add(item1);
            ShoppingList item2 = new ShoppingList("A","Arla Milk",1);
            myshoppinglist.add(item2);
            ShoppingList item3 = new ShoppingList("D","Devondale Milk",2);
            myshoppinglist.add(item3);
            ShoppingList item4 = new ShoppingList("K","Kindle Oasis",3);
            myshoppinglist.add(item4);
            ShoppingList item5 = new ShoppingList("W","waitrose 早餐麦片",4);
            myshoppinglist.add(item5);
            ShoppingList item6 = new ShoppingList("M","Mcvitie's 饼干",5);
            myshoppinglist.add(item6);
            ShoppingList item7 = new ShoppingList("F","Ferrero Rocher",6);
            myshoppinglist.add(item7);
            ShoppingList item8 = new ShoppingList("M","Maltesers",7);
            myshoppinglist.add(item8);
            ShoppingList item9 = new ShoppingList("L","Lindt",8);
            myshoppinglist.add(item9);
            ShoppingList item10= new ShoppingList("B","Borggreve",9);
            myshoppinglist.add(item10);

    }

    private void initShoppingCar(){
        ShoppingList item = new ShoppingList("*","购物车                   价格",10);
        myshoppingcar.add(item);
    }

    private void addToShoppingCar(int number){
        if (number==0){
            ShoppingList item =new ShoppingList("E","Enchated Forest     ￥5.00",0);
            myshoppingcar.add(item);
        }else if(number==1){
            ShoppingList item =new ShoppingList("A","Arla Milk            ￥59.00",1);
            myshoppingcar.add(item);
        }else if (number==2){
            ShoppingList item =new ShoppingList("D","Devondale Milk   ￥79.00",2);
            myshoppingcar.add(item);
        }else if (number==3){
            ShoppingList item =new ShoppingList("K","Kindle Oasis        ￥2399",3);
            myshoppingcar.add(item);
        }else if (number==4){
            ShoppingList item =new ShoppingList("W","waitrose 早餐麦片   ￥179.00",4);
            myshoppingcar.add(item);
        }else if (number==5){
            ShoppingList item =new ShoppingList("M","Mcvitie's 饼干     ￥14.90",5);
            myshoppingcar.add(item);
        }else if (number==6){
            ShoppingList item =new ShoppingList("F","Ferrero Rocher    ￥132.59",6);
            myshoppingcar.add(item);
        }else if (number==7){
            ShoppingList item =new ShoppingList("M","Maltesers         ￥141.43",7);
            myshoppingcar.add(item);
        }else if (number==8){
            ShoppingList item =new ShoppingList("L","Lindt             ￥139.43",8);
            myshoppingcar.add(item);
        }else if (number==9){
            ShoppingList item =new ShoppingList("B","Borggreve         ￥28.90",9);
            myshoppingcar.add(item);
        }
    }
}
