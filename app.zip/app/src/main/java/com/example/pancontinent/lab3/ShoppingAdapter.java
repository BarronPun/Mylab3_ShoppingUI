package com.example.pancontinent.lab3;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.TextView;

import java.util.List;

/**
 * Created by Pancontinent on 2017/10/21.
 */

public class ShoppingAdapter extends RecyclerView.Adapter<ShoppingAdapter.ViewHolder> implements View.OnClickListener, View.OnLongClickListener {
    private List<ShoppingList> mShoppingList;

    static class ViewHolder extends RecyclerView.ViewHolder{
        TextView GoodsLogo, GoodsName;
        public ViewHolder(View view) {
            super(view);
            GoodsLogo = (TextView)view.findViewById(R.id.logo_text);
            GoodsName = (TextView)view.findViewById(R.id.name_text);
        }
    }

    public ShoppingAdapter(List<ShoppingList> shoppinglist) {
        mShoppingList = shoppinglist;
    }

    private OnItemClickListener mOnItemClickListener = null;
    private OnLongItemClickListener mOnLongItemClickListener = null;
    public interface OnItemClickListener{
        void onItemClick(View view, int position);
    }

    public interface OnLongItemClickListener{
        void onLongItemClick(View view, int position);
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.shoppinglist,parent,false);
        ViewHolder holder = new ViewHolder(view);
        //将创建的View 注册点击事件
        view.setOnClickListener(this);
        view.setOnLongClickListener(this);
        return holder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        ShoppingList myshoppinglist = mShoppingList.get(position);
        holder.GoodsLogo.setText(myshoppinglist.getLogo());
        holder.GoodsName.setText(myshoppinglist.getName());
        holder.itemView.setTag(position);
    }

    @Override
    public void onClick(View v) {
        if (mOnItemClickListener != null){
            mOnItemClickListener.onItemClick(v,(int)v.getTag());
        }
    }

    @Override
    public boolean onLongClick(View v) {
        if (mOnLongItemClickListener != null){
            mOnLongItemClickListener.onLongItemClick(v,(int)v.getTag());
        }
        return true;
    }

    public void setOnItemClickListener(OnItemClickListener listener){
        this.mOnItemClickListener = listener;
    }

    public void setOnLongItemClickListener(OnLongItemClickListener listener){
        this.mOnLongItemClickListener = listener;
    }

    @Override
    public int getItemCount() {
        return mShoppingList.size();//返回列表的长度
    }
}
