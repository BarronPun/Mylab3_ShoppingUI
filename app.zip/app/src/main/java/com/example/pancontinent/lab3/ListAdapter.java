package com.example.pancontinent.lab3;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

/**
 * Created by Pancontinent on 2017/10/22.
 */

public class ListAdapter extends ArrayAdapter<ShoppingList> {
    private int resourceId;

    public ListAdapter(Context context, int textViewResourceId,
                       List<ShoppingList> objects){
        super(context,textViewResourceId,objects);
        resourceId = textViewResourceId;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ShoppingList shoppingList = getItem(position);
        View view;
        ViewHolder viewHolder;
        if (convertView == null){
            view = LayoutInflater.from(getContext()).inflate(resourceId,parent,
                    false);
            viewHolder = new ViewHolder();
            viewHolder.logo = (TextView) view.findViewById(R.id.logo_text);
            viewHolder.name = (TextView) view.findViewById(R.id.name_text);
            view.setTag(viewHolder);
        } else{
            view = convertView;
            viewHolder = (ViewHolder) view.getTag();
        }
        viewHolder.logo.setText(shoppingList.getLogo());
        viewHolder.name.setText(shoppingList.getName());
        return view;
        }

    class ViewHolder{
        public TextView logo;
        public TextView name;

    }
}
